﻿using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string source = "banana";   // строка для замены
        char target = 'a';          // символ, который заменяем
        int startPos = 1;           // с какой позиции начинаем
        int n = 2;                  // сколько раз заменяем

        int replacedCount = ReplaceCharRegex(source, target, startPos, n); // вызываем функцию

        Console.WriteLine("Фактическое количество замен: " + replacedCount);

        Console.ReadKey(); // чтобы окно не закрылось
    }

    static int ReplaceCharRegex(string source, char target, int startPos, int n)
    {
        if (source == null)
            throw new ArgumentNullException("Строка не может быть пустой");

        if (startPos < 0 || startPos >= source.Length)
            throw new ArgumentOutOfRangeException("Неверная позиция начала");

        if (n <= 0)
            throw new ArgumentException("Количество замен должно быть больше нуля");

        string firstPart = source.Substring(0, startPos);
        string secondPart = source.Substring(startPos);

        Regex regex = new Regex(Regex.Escape(target.ToString()));

        int count = 0;

        secondPart = regex.Replace(secondPart, match =>
        {
            if (count < n)
            {
                count++;
                return "*";
            }
            return match.Value;
        });

        string result = firstPart + secondPart;

        Console.WriteLine("Результат обработки (Regex): " + result);

        return count;
    }
}
