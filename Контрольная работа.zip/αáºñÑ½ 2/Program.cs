﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.WriteLine(Directory.GetCurrentDirectory());

        string inputFile = "lab6_1.txt";
        string outputFile = "lab6_2.txt";

        char target = 'l';     // заменяемый символ
        int startPos = 3;      // позиция начала
        int n = 2;             // максимальное число замен

        int totalReplacements = 0;

        try
        {
            // Чтение исходных данных из файла (в Main)
            string[] lines = File.ReadAllLines(inputFile);

            // Запись результатов в файл (через пользовательскую функцию)
            WriteResults(outputFile, lines, target, startPos, n, ref totalReplacements);

            Console.WriteLine("Обработка завершена успешно.");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Ошибка: исходный файл не найден.");
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("Ошибка: нет доступа к файлу.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка: " + ex.Message);
        }
    }

    // Пользовательская функция записи результатов в файл
    static void WriteResults(
        string outputFile,
        string[] lines,
        char target,
        int startPos,
        int n,
        ref int totalReplacements)
    {
        using (StreamWriter writer = new StreamWriter(outputFile))
        {
            // В начале файла выводим параметр n
            writer.WriteLine("n = " + n);

            foreach (string line in lines)
            {
                int count;
                string processed = ReplaceChar(line, target, startPos, n, out count);
                totalReplacements += count;
                writer.WriteLine(processed);
            }

            // В конец файла добавляем общее количество замен
            writer.WriteLine("Общее фактическое количество замен: " + totalReplacements);
        }
    }

    // Функция обработки строки
    static string ReplaceChar(string source, char target, int startPos, int n, out int count)
    {
        if (source == null)
            throw new ArgumentNullException("Строка пуста");

        char[] chars = source.ToCharArray();
        count = 0;

        for (int i = startPos; i < chars.Length && count < n; i++)
        {
            if (chars[i] == target)
            {
                chars[i] = '*';
                count++;
            }
        }

        return new string(chars);
    }
}

