﻿using System;

abstract class Array
{
    protected int N;
    protected int[,] Arr;
    protected Random rnd = new Random();

    // Инициализация массива случайными числами
    public void Init(int rows, int cols, int minValue, int maxValue)
    {
        N = rows * cols;
        Arr = new int[rows, cols];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                Arr[i, j] = rnd.Next(minValue, maxValue + 1);
    }

    public abstract double Calc();
    public abstract void PrintArray();
    public abstract void Processing();
}

class Vector : Array
{
    public Vector(int size, int minValue, int maxValue)
    {
        Init(1, size, minValue, maxValue); // одномерный массив 1xN
    }

    public override double Calc()
    {
        try
        {
            int max = Arr[0, 0];
            int min = Arr[0, 0];
            for (int j = 0; j < Arr.GetLength(1); j++)
            {
                if (Arr[0, j] > max) max = Arr[0, j];
                if (Arr[0, j] < min) min = Arr[0, j];
            }
            return (double)max / min;
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Ошибка: деление на ноль при расчёте показателя.");
            return 0;
        }
    }

    public override void PrintArray()
    {
        for (int j = 0; j < Arr.GetLength(1); j++)
            Console.Write(Arr[0, j] + "\t");
        Console.WriteLine();
    }

    public override void Processing()
    {
        double average = 0;
        for (int j = 0; j < Arr.GetLength(1); j++)
            average += Arr[0, j];
        average /= Arr.GetLength(1);

        for (int j = 0; j < Arr.GetLength(1); j++)
            if (Arr[0, j] < average)
                Arr[0, j]--;
    }
}

class Matrix : Array
{
    public Matrix(int rows, int cols, int minValue, int maxValue)
    {
        Init(rows, cols, minValue, maxValue);
    }

    public override double Calc()
    {
        try
        {
            int max = Arr[0, 0];
            int min = Arr[0, 0];
            for (int i = 0; i < Arr.GetLength(0); i++)
                for (int j = 0; j < Arr.GetLength(1); j++)
                {
                    if (Arr[i, j] > max) max = Arr[i, j];
                    if (Arr[i, j] < min) min = Arr[i, j];
                }
            return (double)max / min;
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Ошибка: деление на ноль при расчёте показателя.");
            return 0;
        }
    }

    public override void PrintArray()
    {
        for (int i = 0; i < Arr.GetLength(0); i++)
        {
            for (int j = 0; j < Arr.GetLength(1); j++)
                Console.Write(Arr[i, j] + "\t");
            Console.WriteLine();
        }
    }

    public override void Processing()
    {
        double average = 0;
        int total = Arr.GetLength(0) * Arr.GetLength(1);
        for (int i = 0; i < Arr.GetLength(0); i++)
            for (int j = 0; j < Arr.GetLength(1); j++)
                average += Arr[i, j];
        average /= total;

        for (int i = 0; i < Arr.GetLength(0); i++)
            for (int j = 0; j < Arr.GetLength(1); j++)
                if (Arr[i, j] < average)
                    Arr[i, j]--;
    }
}

class Program
{
    static void Main()
    {
        try
        {
            int vectorSize = 10;
            int rows = 10;
            int cols = 4;
            int minValue = -40;
            int maxValue = 60;

            Vector v = new Vector(vectorSize, minValue, maxValue);
            Console.WriteLine("Вектор:");
            v.PrintArray();
            Console.WriteLine("Показатель вектора: " + v.Calc());
            v.Processing();
            Console.WriteLine("Вектор после обработки:");
            v.PrintArray();

            Matrix m = new Matrix(rows, cols, minValue, maxValue);
            Console.WriteLine("\nМатрица:");
            m.PrintArray();
            Console.WriteLine("Показатель матрицы: " + m.Calc());
            m.Processing();
            Console.WriteLine("Матрица после обработки:");
            m.PrintArray();
        }
        catch (Exception e)
        {
            Console.WriteLine("Ошибка: " + e.Message);
        }

        Console.ReadLine();
    }
}

