﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

// Класс тестов для Vector и Matrix
[TestClass]
public class ArrayTests
{
    // Тест метода Calc() для Vector
    [TestMethod]
    public void Vector_Calc_Test()
    {
        var v = new Vector(10, -40, 60);
        double result = v.Calc();
        // Проверяем, что показатель вектора не равен 0
        Assert.IsTrue(result != 0, "Показатель вектора не должен быть 0");
    }

    // Тест метода Processing() для Vector
    [TestMethod]
    public void Vector_Processing_Test()
    {
        var v = new Vector(10, -40, 60);
        v.Processing();
        // Проверка, что метод завершился без ошибок
        Assert.IsTrue(true);
    }

    // Тест метода Calc() для Matrix
    [TestMethod]
    public void Matrix_Calc_Test()
    {
        var m = new Matrix(10, 4, -40, 60);
        double result = m.Calc();
        // Проверяем, что показатель матрицы не равен 0
        Assert.IsTrue(result != 0, "Показатель матрицы не должен быть 0");
    }

    // Тест обработки исключения DivideByZero для Vector
    [TestMethod]
    public void Vector_DivideByZero_Test()
    {
        var vZero = new Vector(5, 0, 0); // все элементы = 0
        bool exceptionThrown = false;

        try
        {
            double result = vZero.Calc(); // должно вызвать исключение
        }
        catch (DivideByZeroException)
        {
            exceptionThrown = true; // исключение поймано — тест пройден
        }

        Assert.IsTrue(exceptionThrown, "Ожидаемое исключение DivideByZeroException не было вызвано");
    }
}
