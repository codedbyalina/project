﻿using System;

namespace Lab3_ClassArray
{
    class DynamicArray
    {
        private int n;       // Длина массива
        private int[] ar;    // Ссылка на массив

        // Конструктор без параметров (инициализация нулями)
        public DynamicArray()
        {
            n = 10;                  // Стандартная длина
            ar = new int[n];          // Массив из нулей
            Console.WriteLine("Конструктор без параметров выполнен.");
        }

        // Конструктор с параметрами (длина и диапазон генерации)
        public DynamicArray(int length, int minValue, int maxValue)
        {
            n = length;
            ar = new int[n];
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
                ar[i] = rnd.Next(minValue, maxValue + 1);
            Console.WriteLine("Конструктор с параметрами выполнен.");
        }

        // Копирующий конструктор
        public DynamicArray(DynamicArray other)
        {
            n = other.n;
            ar = new int[n];
            for (int i = 0; i < n; i++)
                ar[i] = other.ar[i];
            Console.WriteLine("Копирующий конструктор выполнен.");
        }

        // Деструктор
        ~DynamicArray()
        {
            Console.WriteLine("Деструктор выполнен.");
        }

        // Метод модификации элемента массива по индексу
        public void ModifyElement(int index, int value)
        {
            try
            {
                ar[index] = value;
                Console.WriteLine($"Элемент с индексом {index} изменен на {value}.");
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Ошибка: индекс выходит за границы массива.");
            }
        }

        // Метод обработки массива по условию: уменьшить на 1 элементы < среднего
        public void ProcessArray()
        {
            try
            {
                double average = 0;
                foreach (int val in ar)
                    average += val;
                average /= n;

                for (int i = 0; i < n; i++)
                {
                    if (ar[i] < average)
                        ar[i] -= 1;
                }
                Console.WriteLine("Обработка массива выполнена.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при обработке массива: " + ex.Message);
            }
        }

        // Метод вывода массива на консоль
        public void PrintArray()
        {
            for (int i = 0; i < n; i++)
                Console.Write("{0,6}", ar[i]);
            Console.WriteLine();
        }

        // Перегруженный оператор — (например, для уменьшения всех элементов на 1)
        public static DynamicArray operator --(DynamicArray arr)
        {
            for (int i = 0; i < arr.n; i++)
                arr.ar[i]--;
            return arr;
        }

        // Метод быстрой сортировки
        public void QuickSort()
        {
            try
            {
                QuickSortInternal(0, n - 1);
                Console.WriteLine("Сортировка массива выполнена.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка сортировки: " + ex.Message);
            }
        }

        private void QuickSortInternal(int left, int right)
        {
            if (left >= right) return;
            int pivot = ar[right];
            int i = left - 1;

            for (int j = left; j < right; j++)
            {
                if (ar[j] <= pivot)
                {
                    i++;
                    int temp = ar[i];
                    ar[i] = ar[j];
                    ar[j] = temp;
                }
            }

            int tmp = ar[i + 1];
            ar[i + 1] = ar[right];
            ar[right] = tmp;

            QuickSortInternal(left, i);
            QuickSortInternal(i + 2, right);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Создание массива ar0 нулевой длины
            DynamicArray ar0 = new DynamicArray();
            Console.WriteLine("Массив ar0:");
            ar0.PrintArray();

            // Создание массива ar1 с длиной с клавиатуры
            int length = 0;
            Console.Write("Введите длину массива ar1: ");
            try
            {
                length = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка ввода. Используем длину 10.");
                length = 10;
            }

            DynamicArray ar1 = new DynamicArray(length, -40, 60);
            Console.WriteLine("Исходный массив ar1:");
            ar1.PrintArray();

            // Копирование массива ar1 в arN
            DynamicArray arN = new DynamicArray(ar1);
            Console.WriteLine("Скопированный массив arN:");
            arN.PrintArray();

            // Модификация элементов ar1
            ar1.ModifyElement(0, 100);
            ar1.ModifyElement(length - 1, -100);
            ar1.ModifyElement(length + 1, 0); // Искусственная ошибка для проверки

            Console.WriteLine("Массив ar1 после модификации:");
            ar1.PrintArray();

            // Обработка массива arN
            arN.ProcessArray();
            Console.WriteLine("Массив arN после обработки:");
            arN.PrintArray();

            // Применение перегруженного оператора
            arN--;
            Console.WriteLine("Массив arN после применения оператора '--':");
            arN.PrintArray();

            // Сортировка массива arN
            arN.QuickSort();
            Console.WriteLine("Массив arN после сортировки:");
            arN.PrintArray();

            Console.ReadKey();
        }
    }
}
