﻿using System;

namespace MatrixInheritance
{
    // Базовый класс Array
    public class Array
    {
        public int n;
        public int[] ar;

        public Array()
        {
            n = 10;
            ar = new int[n];
            for (int i = 0; i < n; i++)
                ar[i] = 0;
            Console.WriteLine("Array без параметров выполнен.");
        }

        public Array(int n)
        {
            this.n = n;
            ar = new int[n];
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
                ar[i] = rnd.Next(-40, 61);
            Console.WriteLine("Array с параметрами выполнен.");
        }

        public Array(Array other)
        {
            n = other.n;
            ar = new int[n];
            for (int i = 0; i < n; i++)
                ar[i] = other.ar[i];
            Console.WriteLine("Копирующий конструктор Array выполнен.");
        }

        public void PrintArray()
        {
            for (int i = 0; i < n; i++)
                Console.Write($"{ar[i],5}");
            Console.WriteLine();
        }

        // Перегрузка унарного оператора - возвращает новый объект
        public static Array operator -(Array a)
        {
            Array result = new Array(a);
            for (int i = 0; i < a.n; i++)
                result.ar[i] = -result.ar[i];
            return result;
        }
    }

    // Производный класс Matrix
    public class Matrix
    {
        private int m;
        private int n;
        private Array[] matr;

        public double P { get; private set; }

        // Конструктор без параметров
        public Matrix()
        {
            m = 10;
            n = 4;
            matr = new Array[m];
            for (int i = 0; i < m; i++)
                matr[i] = new Array(n);

            ComputeP();
            Console.WriteLine("Matrix без параметров выполнен.");
        }

        // Конструктор с параметрами
        public Matrix(int m, int n)
        {
            this.m = m;
            this.n = n;
            matr = new Array[m];
            Random rnd = new Random();
            for (int i = 0; i < m; i++)
            {
                matr[i] = new Array(n);
                for (int j = 0; j < n; j++)
                    matr[i].ar[j] = rnd.Next(-40, 61);
            }

            ComputeP();
            Console.WriteLine("Matrix с параметрами выполнен.");
        }

        // Метод вывода матрицы
        public void PrintMatrix()
        {
            for (int i = 0; i < m; i++)
                matr[i].PrintArray();
        }

        // Вычисление показателя P = max / min
        public void ComputeP()
        {
            int max = matr[0].ar[0];
            int min = matr[0].ar[0];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                {
                    if (matr[i].ar[j] > max) max = matr[i].ar[j];
                    if (matr[i].ar[j] < min) min = matr[i].ar[j];
                }

            P = (min != 0) ? (double)max / min : double.PositiveInfinity;
        }

        // Преобразование матрицы: уменьшить элементы меньше среднего на 1
        public void TransformMatrix()
        {
            for (int i = 0; i < m; i++)
            {
                double sum = 0;
                for (int j = 0; j < n; j++)
                    sum += matr[i].ar[j];
                double avg = sum / n;

                for (int j = 0; j < n; j++)
                    if (matr[i].ar[j] < avg)
                        matr[i].ar[j] -= 1;
            }
        }

        // Быстрая сортировка строк матрицы по возрастанию
        public void SortMatrix()
        {
            for (int i = 0; i < m; i++)
                QuickSort(matr[i].ar, 0, n - 1);
        }

        private void QuickSort(int[] arr, int left, int right)
        {
            if (left >= right) return;
            int pivot = arr[(left + right) / 2];
            int i = left, j = right;
            while (i <= j)
            {
                while (arr[i] < pivot) i++;
                while (arr[j] > pivot) j--;
                if (i <= j)
                {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                    i++;
                    j--;
                }
            }
            if (left < j) QuickSort(arr, left, j);
            if (i < right) QuickSort(arr, i, right);
        }

        // Перегрузка оператора унарного минуса для матрицы (возвращает новый объект)
        public static Matrix operator -(Matrix mtx)
        {
            Matrix result = new Matrix(mtx.m, mtx.n);
            for (int i = 0; i < mtx.m; i++)
                result.matr[i] = -mtx.matr[i]; // Используем перегрузку Array
            return result;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Matrix m0 = new Matrix();
                Console.WriteLine("\nМатрица по умолчанию:");
                m0.PrintMatrix();
                Console.WriteLine($"P = {m0.P:F2}\n");

                Matrix m1 = new Matrix(10, 4);
                Console.WriteLine("\nИсходная матрица:");
                m1.PrintMatrix();
                Console.WriteLine($"P = {m1.P:F2}\n");

                m1.TransformMatrix();
                Console.WriteLine("После преобразования (уменьшение элементов < среднего на 1):");
                m1.PrintMatrix();

                m1.SortMatrix();
                Console.WriteLine("\nОтсортированная матрица:");
                m1.PrintMatrix();

                // Применение перегруженного оператора '-'
                Matrix m2 = -m1; // создается новый объект
                Console.WriteLine("\nПосле применения унарного оператора '-' (новый объект):");
                m2.PrintMatrix();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }

            Console.ReadKey();
        }
    }
}

